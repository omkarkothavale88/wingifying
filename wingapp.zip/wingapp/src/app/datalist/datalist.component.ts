import { Component, OnInit, TemplateRef } from '@angular/core';

@Component({
  selector: 'app-datalist',
  templateUrl: './datalist.component.html',
  styleUrls: ['./datalist.component.scss']
})
export class DatalistComponent implements OnInit {
  listOption = null;
  primaryArr: any = [
    { name: 'Amber' },
    { name: 'Brett' },
    { name: 'Castle' },
    { name: 'Daniel' }
  ];

  selectedArr: any = [];
  showModal = false;
  secondaryArr: any = [];
  enablePrimaryBtn: boolean = false;
  enableSecondaryBtn: boolean = false;

  constructor() {}

  ngOnInit(): void {
    this.selectedArr = [];
  }

  changeSelection = (item: any, data: any, isPrimary: boolean) => {
    if (data.target.checked) {
      this.selectedArr.push(item);
    } else {
      this.selectedArr.splice(this.primaryArr.indexOf(item), 1);
    }

    if (data.target.checked && this.selectedArr.length > 0 && isPrimary) {
      this.enablePrimaryBtn = false;
      this.enableSecondaryBtn = true;
    } else if (
      !isPrimary &&
      data.target.checked &&
      this.selectedArr.length > 0
    ) {
      this.enablePrimaryBtn = true;
      this.enableSecondaryBtn = false;
    } else {
      this.enablePrimaryBtn = false;
      this.enableSecondaryBtn = false;
    }
  };

  MoveToSecondary = () => {
    if (this.primaryArr.length) {
      this.secondaryArr = [...this.selectedArr];
      this.primaryArr = this.primaryArr.filter(
        (val: any) => this.selectedArr.indexOf(val) == -1
      );
    }
    this.selectedArr = [];
  };

  MoveToPrimary = () => {
    this.selectedArr.map((val: any) => {
      if (this.primaryArr.indexOf(val) == -1 && this.primaryArr.length < 11) {
        this.primaryArr.push(val);
      }
    });
    this.secondaryArr = this.secondaryArr.filter(
      (val: any) => this.selectedArr.indexOf(val) == -1
    );
    this.selectedArr = [];
    console.log(this.secondaryArr);
  };

  deleteItems = () => {
    this.primaryArr = this.primaryArr.filter((item: any) => {
      return this.selectedArr.indexOf(item) == -1;
    });
    this.selectedArr = [];
  };

  addItem = () => {
    this.showModal = true;
  };
  submit = () => {
    if (this.listOption == 'A') {
      if (this.primaryArr.length < 11) {
        this.primaryArr.push({});
      }
    }

    if (this.listOption == 'B') {
      if (this.secondaryArr.length < 11) {
        this.secondaryArr.push({});
      }
    }

  };
}
